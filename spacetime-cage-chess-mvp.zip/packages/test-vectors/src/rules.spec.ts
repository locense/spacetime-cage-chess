import { describe, expect, it } from "vitest";
import fc from "fast-check";
import { LOGICAL_SQUARES, PORTAL_IDS, applyMove, initialState, isAttacked, legalMovesForSide, nextLogicalSquare, normalizeSquare, pieceAt, positionKey, pseudoMovesForPiece, resolveTerminal, type GameState, type Piece } from "@cage/rules";

function state(pieces: Piece[], opened: string[] = [], side: "white" | "black" = "white"): GameState {
  const base = initialState();
  base.pieces = pieces;
  base.sideToMove = side;
  for (const portal of opened) base.portals[portal as keyof typeof base.portals] = true;
  base.repetitionHistory = { [positionKey(base)]: 1 };
  return base;
}
const piece = (id: string, color: "white" | "black", type: Piece["type"], square: Piece["square"], hasMoved = true): Piece => ({ id, color, type, square, hasMoved });
const kings = () => [piece("wk", "white", "king", "e2"), piece("bk", "black", "king", "e7")];

describe("Section 17: topology and occupancy", () => {
  it("normalizes aliases and maps four corners to one black hole", () => {
    expect(normalizeSquare("A4")).toBe("P4"); expect(normalizeSquare("h4")).toBe("P4");
    expect(normalizeSquare("e1")).toBe(normalizeSquare("e8"));
    expect(new Set(["a1", "h1", "a8", "h8"].map(normalizeSquare))).toEqual(new Set(["X"]));
    expect(LOGICAL_SQUARES).toHaveLength(48);
  });
  it("uses a single occupancy for aliases", () => {
    const s = state([...kings(), piece("wr", "white", "rook", "P4")], ["H4"]);
    expect(pieceAt(s, normalizeSquare("a4") as "P4")?.id).toBe("wr");
    expect(pieceAt(s, normalizeSquare("h4") as "P4")?.id).toBe("wr");
  });
});

describe("Section 17: portals and paths", () => {
  it("keeps a closed portal out of ordinary movement and opens it atomically on capture", () => {
    const s = state([...kings(), piece("wr", "white", "rook", "b4")]);
    const rook = s.pieces.find((p) => p.id === "wr")!;
    const capture = pseudoMovesForPiece(s, rook).find((m) => m.to === "P4" && m.kind === "portal-capture")!;
    const next = applyMove(s, capture)!;
    expect(next.portals.H4).toBe(true); expect(pieceAt(next, "P4")?.id).toBe("wr");
    expect(pseudoMovesForPiece(s, rook).filter((m) => m.to === "P4")).toEqual([capture]);
  });
  it("opens portals independently", () => {
    const s = state([...kings(), piece("wr", "white", "rook", "b4")]);
    const next = applyMove(s, pseudoMovesForPiece(s, s.pieces[2]!).find((m) => m.to === "P4")!)!;
    expect(next.portals.H4).toBe(true); expect(next.portals.H3).toBe(false); expect(next.portals.Ve).toBe(false);
  });
  it("allows a slider to capture either a horizontal or vertical closed portal and stop there", () => {
    const horizontal = state([...kings(), piece("wr", "white", "rook", "b4")]);
    expect(pseudoMovesForPiece(horizontal, horizontal.pieces[2]!).some((m) => m.to === "P4" && m.kind === "portal-capture")).toBe(true);
    const vertical = state([...kings(), piece("wb", "white", "bishop", "d2")]);
    expect(pseudoMovesForPiece(vertical, vertical.pieces[2]!).some((m) => m.to === "eQ" && m.kind === "portal-capture")).toBe(true);
  });
  it("traverses open horizontal and vertical portals", () => {
    const horizontal = state([...kings(), piece("wr", "white", "rook", "g2")], ["H2"]);
    expect(pseudoMovesForPiece(horizontal, horizontal.pieces[2]!).map((m) => m.to)).toContain("b2");
    const vertical = state([...kings(), piece("wr", "white", "rook", "g7")], ["Vg"]);
    expect(pseudoMovesForPiece(vertical, vertical.pieces[2]!).map((m) => m.to)).toContain("g2");
  });
  it("reproduces the prescribed diagonal cycle without adding its origin", () => {
    const s = state([...kings(), piece("wb", "white", "bishop", "g3")], ["H4", "Ve"]);
    const to = pseudoMovesForPiece(s, s.pieces[2]!).map((m) => m.to);
    for (const square of ["P4", "b5", "c6", "d7", "eQ", "f2"]) expect(to).toContain(square);
    expect(to).not.toContain("g3");
  });
  it("tests opposite horizontal routes independently and deduplicates the endpoint", () => {
    const s = state([...kings(), piece("wr", "white", "rook", "g2"), piece("block", "white", "bishop", "e2")], ["H2"]);
    expect(pseudoMovesForPiece(s, s.pieces[2]!).filter((m) => m.to === "d2")).toHaveLength(1);
  });
  it("enforces black-hole and non-black-hole boundaries", () => {
    expect(nextLogicalSquare("g7", 1, 1)).toBe("X"); expect(nextLogicalSquare("b7", -1, 1)).toBe("X");
    expect(nextLogicalSquare("g2", 1, -1)).toBe("X"); expect(nextLogicalSquare("b2", -1, -1)).toBe("X");
    expect(nextLogicalSquare("P2", -1, -1)).toBe("gQ"); expect(nextLogicalSquare("P7", 1, 1)).toBe("bQ");
    expect(nextLogicalSquare("gQ", 1, 1)).toBe("P2");
  });
});

describe("Section 17: pieces", () => {
  it("limits kings to one logical step", () => {
    const s = state([...kings(), piece("wk2", "white", "king", "g3")], ["H4"]);
    const king = s.pieces.find((p) => p.id === "wk2")!;
    expect(pseudoMovesForPiece(s, king).map((m) => m.to)).toContain("P4"); expect(pseudoMovesForPiece(s, king).map((m) => m.to)).not.toContain("b5");
  });
  it("keeps pawn forward and diagonal building behavior distinct", () => {
    const forwardClosed = state([...kings(), piece("wp", "white", "pawn", "P3")]);
    expect(pseudoMovesForPiece(forwardClosed, forwardClosed.pieces[2]!).some((m) => m.to === "P4")).toBe(false);
    const diagonalClosed = state([...kings(), piece("wp", "white", "pawn", "b3")]);
    expect(pseudoMovesForPiece(diagonalClosed, diagonalClosed.pieces[2]!).some((m) => m.to === "P4" && m.kind === "portal-capture")).toBe(true);
  });
  it("supports specified pawn doubles, expiry-aware en passant, and promotion choices", () => {
    const white = state([...kings(), piece("wp", "white", "pawn", "c3", false)]);
    expect(pseudoMovesForPiece(white, white.pieces[2]!).some((m) => m.to === "c5" && m.isDoublePawnStep)).toBe(true);
    const black = state([...kings(), piece("bp", "black", "pawn", "c6", false)], [], "black");
    expect(pseudoMovesForPiece(black, black.pieces[2]!).some((m) => m.to === "c4" && m.isDoublePawnStep)).toBe(true);
    const promote = state([...kings(), piece("wp", "white", "pawn", "c6")]);
    expect(pseudoMovesForPiece(promote, promote.pieces[2]!).filter((m) => m.to === "c7").map((m) => m.promotion).sort()).toEqual(["bishop", "queen", "rook"]);
  });
  it("provides each eligible adjacent en-passant capture once", () => {
    const s = state([...kings(), piece("bp", "black", "pawn", "c5"), piece("wp", "white", "pawn", "d3", false)], [], "white");
    const double = pseudoMovesForPiece(s, s.pieces.find((p) => p.id === "wp")!).find((m) => m.isDoublePawnStep)!;
    const after = applyMove(s, double)!;
    expect(legalMovesForSide(after).filter((m) => m.kind === "en-passant" && m.pieceId === "bp")).toHaveLength(1);
  });
  it("expires en-passant after any non-en-passant reply and rejects knight promotion", () => {
    const s = state([...kings(), piece("bp", "black", "pawn", "c5"), piece("wp", "white", "pawn", "d3", false)], [], "white");
    const afterDouble = applyMove(s, pseudoMovesForPiece(s, s.pieces.find((p) => p.id === "wp")!).find((m) => m.isDoublePawnStep)!)!;
    const kingReply = legalMovesForSide(afterDouble).find((m) => m.pieceId === "bk" && m.kind === "quiet")!;
    const afterReply = applyMove(afterDouble, kingReply)!;
    expect(afterReply.enPassant).toBeNull();
    const promotion = state([...kings(), piece("wp", "white", "pawn", "c6")]);
    const illegalKnight = { ...pseudoMovesForPiece(promotion, promotion.pieces[2]!).find((m) => m.to === "c7")!, promotion: "knight" as never };
    expect(applyMove(promotion, illegalKnight)).toBeNull();
  });
  it("does not generate castling-like king moves", () => {
    const s = state([...kings()]);
    expect(pseudoMovesForPiece(s, s.pieces.find((p) => p.id === "wk")!).some((m) => m.to === "g2" || m.to === "c2")).toBe(false);
  });
});

describe("Section 17: king safety and outcomes", () => {
  it("rolls back a portal capture that exposes its own king", () => {
    const s = state([piece("wk", "white", "king", "b2"), piece("bk", "black", "king", "e7"), piece("br", "black", "rook", "b7"), piece("wb", "white", "bishop", "c2")]);
    const attempted = pseudoMovesForPiece(s, s.pieces.find((p) => p.id === "wb")!).find((m) => m.to === "bQ" && m.kind === "portal-capture")!;
    expect(applyMove(s, attempted)).toBeNull();
    expect(s.portals.Vb).toBe(false);
  });
  it("recognizes attacks separately from executable king captures", () => {
    const s = state([piece("wk", "white", "king", "c4"), piece("bk", "black", "king", "e7"), piece("br", "black", "rook", "c6")]);
    expect(isAttacked(s, "c4", "black")).toBe(true);
    expect(legalMovesForSide(s).some((m) => m.pieceId === "wk" && m.to === "c5")).toBe(false);
  });
  it("allows a king to capture an adjacent building only if the opened position remains safe", () => {
    const s = state([piece("wk", "white", "king", "g3"), piece("bk", "black", "king", "e7")]);
    const capture = pseudoMovesForPiece(s, s.pieces[0]!).find((m) => m.to === "P4" && m.kind === "portal-capture")!;
    const next = applyMove(s, capture)!;
    expect(next.portals.H4).toBe(true); expect(next.pieces.find((p) => p.id === "wk")?.square).toBe("P4");
  });
  it("prioritizes checkmate and settles stalemate via the count phase", () => {
    const mate = state([piece("wk", "white", "king", "e2"), piece("bk", "black", "king", "e7"), piece("bq", "black", "queen", "e3"), piece("br", "black", "rook", "e4")]);
    expect(resolveTerminal(mate).result).toBe("black-win");
    const stalemate = state([piece("wk", "white", "king", "e2"), piece("bk", "black", "king", "e7"), piece("bq", "black", "queen", "d4"), piece("br", "black", "rook", "f4")]);
    expect(resolveTerminal(stalemate).result).toBe("black-win");
  });
  it("settles bare kings and threefold repetition by count, without a fifty-move rule", () => {
    const bare = resolveTerminal(state(kings())); expect(bare.result).toBe("draw");
    const repeated = state([...kings(), piece("wp", "white", "pawn", "c3")]); repeated.repetitionHistory[positionKey(repeated)] = 3;
    expect(resolveTerminal(repeated).result).toBe("white-win");
  });
  it("keys side, portals, pawn double eligibility, and en-passant; dead status stays injectable", () => {
    const s = initialState(); const initialKey = positionKey(s);
    const changedSide = structuredClone(s); changedSide.sideToMove = "black";
    const changedPortal = structuredClone(s); changedPortal.portals.H2 = true;
    const changedPawn = structuredClone(s); changedPawn.pieces.find((p) => p.id === "wp-b")!.hasMoved = true;
    const changedEp = structuredClone(s); changedEp.enPassant = { target: "b4", pawnId: "wp-b", pawnSquare: "b5", capturingSide: "black" };
    expect(new Set([initialKey, positionKey(changedSide), positionKey(changedPortal), positionKey(changedPawn), positionKey(changedEp)])).toHaveLength(5);
    const dead = state([...kings(), piece("wp", "white", "pawn", "c3")]);
    expect(resolveTerminal(dead, { isCertifiedDeadPosition: () => true }).result).toBe("white-win");
  });
});

describe("properties", () => {
  it("normalization is alias-idempotent and all logical steps avoid a false corner", () => {
    fc.assert(fc.property(fc.constantFrom("a2", "h2", "a4", "h4", "b1", "b8", "a1", "h8"), (coordinate) => {
      const square = normalizeSquare(coordinate); return square === "X" || normalizeSquare((square.startsWith("P") ? "a" : square[0]!) + (square.endsWith("Q") ? "1" : square.slice(1))) === square;
    }));
  });
  it("every generated move has a canonical non-black-hole target and a portal invariant", () => {
    fc.assert(fc.property(fc.constantFrom(...LOGICAL_SQUARES), (origin) => {
      const s = state([...kings(), piece("wr", "white", "rook", origin)]); const moves = pseudoMovesForPiece(s, s.pieces[2]!);
      return moves.every((move) => move.kind !== "portal-capture" || move.portalId !== undefined);
    }));
  });
});
