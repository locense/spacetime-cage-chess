import { aliases, isClosedPortal, nextLogicalSquare, portalAt, squareParts } from "./topology.js";
import { opposite } from "./state.js";
import type { Color, DeadPositionDetector, EnPassant, GameState, LogicalSquare, Move, MoveKind, Piece, PieceType, PortalId, Promotion, Result } from "./types.js";

const ROOK_DIRECTIONS: ReadonlyArray<readonly [number, number]> = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const BISHOP_DIRECTIONS: ReadonlyArray<readonly [number, number]> = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
const KING_DIRECTIONS: ReadonlyArray<readonly [number, number]> = [...ROOK_DIRECTIONS, ...BISHOP_DIRECTIONS];
const PROMOTIONS: Promotion[] = ["queen", "rook", "bishop"];

export function pieceAt(state: Readonly<GameState>, square: Exclude<LogicalSquare, "X">): Piece | undefined {
  return state.pieces.find((piece) => piece.square === square);
}
export function kingSquare(state: Readonly<GameState>, color: Color): Exclude<LogicalSquare, "X"> | undefined {
  return state.pieces.find((piece) => piece.color === color && piece.type === "king")?.square;
}

function makeMove(piece: Piece, to: Exclude<LogicalSquare, "X">, kind: MoveKind, options: Partial<Move> = {}): Move[] {
  const base: Move = { pieceId: piece.id, from: piece.square, to, kind, ...options };
  const promotionRank = piece.color === "white" ? "7" : "2";
  return piece.type === "pawn" && squareParts(to).rank === promotionRank
    ? PROMOTIONS.map((promotion) => ({ ...base, promotion }))
    : [base];
}

function slidingMoves(state: Readonly<GameState>, piece: Piece, directions: ReadonlyArray<readonly [number, number]>): Move[] {
  const moves: Move[] = [];
  for (const [df, dr] of directions) {
    const visited = new Set<LogicalSquare>([piece.square]);
    let current = piece.square;
    while (true) {
      const target = nextLogicalSquare(current, df, dr);
      if (target === "X" || visited.has(target)) break;
      visited.add(target);
      const occupant = pieceAt(state, target);
      if (occupant?.color === piece.color) break;
      if (occupant?.type === "king") break;
      if (occupant) { moves.push(...makeMove(piece, target, "capture", { capturedId: occupant.id })); break; }
      const portal = portalAt(target);
      if (portal !== undefined && !state.portals[portal]) { moves.push(...makeMove(piece, target, "portal-capture", { portalId: portal })); break; }
      moves.push(...makeMove(piece, target, "quiet"));
      current = target;
    }
  }
  return moves;
}

function kingMoves(state: Readonly<GameState>, piece: Piece): Move[] {
  const moves: Move[] = [];
  for (const [df, dr] of KING_DIRECTIONS) {
    const target = nextLogicalSquare(piece.square, df, dr);
    if (target === "X") continue;
    const occupant = pieceAt(state, target);
    if (occupant?.color === piece.color || occupant?.type === "king") continue;
    if (occupant) moves.push(...makeMove(piece, target, "capture", { capturedId: occupant.id }));
    else {
      const portal = portalAt(target);
      moves.push(...makeMove(piece, target, portal !== undefined && !state.portals[portal] ? "portal-capture" : "quiet", portal !== undefined && !state.portals[portal] ? { portalId: portal } : {}));
    }
  }
  return moves;
}

function pawnMoves(state: Readonly<GameState>, piece: Piece): Move[] {
  const moves: Move[] = [];
  const forward = piece.color === "white" ? 1 : -1;
  const one = nextLogicalSquare(piece.square, 0, forward);
  if (one !== "X" && !pieceAt(state, one) && !isClosedPortal(state, one)) {
    moves.push(...makeMove(piece, one, "quiet"));
    const startRank = piece.color === "white" ? "3" : "6";
    if (!piece.hasMoved && squareParts(piece.square).rank === startRank) {
      const two = nextLogicalSquare(one, 0, forward);
      if (two !== "X" && !pieceAt(state, two) && !isClosedPortal(state, two)) moves.push(...makeMove(piece, two, "quiet", { isDoublePawnStep: true }));
    }
  }
  for (const df of [-1, 1]) {
    const target = nextLogicalSquare(piece.square, df, forward);
    if (target === "X") continue;
    const occupant = pieceAt(state, target);
    if (occupant && occupant.color !== piece.color && occupant.type !== "king") {
      moves.push(...makeMove(piece, target, "capture", { capturedId: occupant.id }));
      continue;
    }
    const portal = portalAt(target);
    if (!occupant && portal !== undefined && !state.portals[portal]) {
      moves.push(...makeMove(piece, target, "portal-capture", { portalId: portal }));
      continue;
    }
    const ep = state.enPassant;
    if (!occupant && ep && ep.capturingSide === piece.color && ep.target === target) {
      const captured = state.pieces.find((candidate) => candidate.id === ep.pawnId && candidate.square === ep.pawnSquare && candidate.type === "pawn" && candidate.color !== piece.color);
      if (captured) moves.push(...makeMove(piece, target, "en-passant", { capturedId: captured.id }));
    }
  }
  return moves;
}

export function pseudoMovesForPiece(state: Readonly<GameState>, piece: Piece): Move[] {
  const candidates = (() => {
  switch (piece.type) {
    case "rook": return slidingMoves(state, piece, ROOK_DIRECTIONS);
    case "bishop": return slidingMoves(state, piece, BISHOP_DIRECTIONS);
    case "queen": return slidingMoves(state, piece, KING_DIRECTIONS);
    case "king": return kingMoves(state, piece);
    case "pawn": return pawnMoves(state, piece);
  }
  })();
  const seen = new Set<string>();
  return candidates.filter((move) => {
    const key = `${move.pieceId}|${move.from}|${move.to}|${move.kind}|${move.capturedId ?? ""}|${move.portalId ?? ""}|${move.promotion ?? ""}|${Boolean(move.isDoublePawnStep)}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export function isAttacked(state: Readonly<GameState>, target: Exclude<LogicalSquare, "X">, byColor: Color): boolean {
  for (const piece of state.pieces) {
    if (piece.color !== byColor) continue;
    if (piece.type === "pawn") {
      const forward = piece.color === "white" ? 1 : -1;
      if ([-1, 1].some((df) => nextLogicalSquare(piece.square, df, forward) === target)) return true;
      continue;
    }
    if (piece.type === "king") {
      if (KING_DIRECTIONS.some(([df, dr]) => nextLogicalSquare(piece.square, df, dr) === target)) return true;
      continue;
    }
    const directions = piece.type === "rook" ? ROOK_DIRECTIONS : piece.type === "bishop" ? BISHOP_DIRECTIONS : KING_DIRECTIONS;
    for (const [df, dr] of directions) {
      const visited = new Set<LogicalSquare>([piece.square]);
      let current = piece.square;
      while (true) {
        const next = nextLogicalSquare(current, df, dr);
        if (next === "X" || visited.has(next)) break;
        visited.add(next);
        if (next === target) return true;
        if (isClosedPortal(state, next) || pieceAt(state, next)) break;
        current = next;
      }
    }
  }
  return false;
}

function moveMatches(candidate: Move, requested: Move): boolean {
  return candidate.pieceId === requested.pieceId && candidate.from === requested.from && candidate.to === requested.to && candidate.kind === requested.kind && candidate.capturedId === requested.capturedId && candidate.portalId === requested.portalId && candidate.promotion === requested.promotion && Boolean(candidate.isDoublePawnStep) === Boolean(requested.isDoublePawnStep);
}

function cloneState(state: Readonly<GameState>): GameState { return structuredClone(state); }

function applyMoveInternal(state: Readonly<GameState>, move: Move, resolveAfterMove: boolean): GameState | null {
  if (state.phase !== "active") return null;
  const originalPiece = state.pieces.find((piece) => piece.id === move.pieceId);
  if (!originalPiece || originalPiece.color !== state.sideToMove || originalPiece.square !== move.from) return null;
  if (!pseudoMovesForPiece(state, originalPiece).some((candidate) => moveMatches(candidate, move))) return null;
  const next = cloneState(state);
  const moving = next.pieces.find((piece) => piece.id === move.pieceId)!;
  if (move.kind === "capture" || move.kind === "en-passant") {
    if (!move.capturedId) return null;
    const index = next.pieces.findIndex((piece) => piece.id === move.capturedId && piece.type !== "king");
    if (index < 0) return null;
    next.pieces.splice(index, 1);
  }
  if (move.kind === "portal-capture") {
    if (!move.portalId || next.portals[move.portalId]) return null;
    next.portals[move.portalId] = true;
  }
  moving.square = move.to;
  if (moving.type === "pawn") moving.hasMoved = true;
  if (move.promotion) moving.type = move.promotion;
  const ownKing = kingSquare(next, moving.color);
  if (!ownKing || isAttacked(next, ownKing, opposite(moving.color))) return null;
  next.enPassant = null;
  if (move.isDoublePawnStep) {
    const direction = moving.color === "white" ? 1 : -1;
    const target = nextLogicalSquare(move.from, 0, direction);
    if (target === "X") return null;
    next.enPassant = { target, pawnId: moving.id, pawnSquare: moving.square, capturingSide: opposite(moving.color) };
  }
  next.sideToMove = opposite(moving.color);
  const key = positionKey(next);
  next.repetitionHistory[key] = (next.repetitionHistory[key] ?? 0) + 1;
  return resolveAfterMove ? resolveTerminal(next) : next;
}

export function applyMove(state: Readonly<GameState>, move: Move): GameState | null {
  return applyMoveInternal(state, move, true);
}

export function legalMovesForSide(state: Readonly<GameState>, side = state.sideToMove): Move[] {
  if (state.phase !== "active") return [];
  return state.pieces.filter((piece) => piece.color === side).flatMap((piece) => pseudoMovesForPiece(state, piece).filter((move) => applyMoveInternal({ ...state, sideToMove: side }, move, false) !== null));
}

export function positionKey(state: Readonly<GameState>): string {
  const pieces = state.pieces.map((piece) => `${piece.color[0]}:${piece.type}:${piece.square}:${piece.type === "pawn" && !piece.hasMoved ? "d" : "-"}`).sort().join(",");
  const portals = Object.entries(state.portals).sort(([a], [b]) => a.localeCompare(b)).map(([id, open]) => `${id}:${open ? 1 : 0}`).join(",");
  const ep = state.enPassant ? `${state.enPassant.target}:${state.enPassant.pawnSquare}:${state.enPassant.capturingSide}` : "-";
  return `${state.sideToMove}|${pieces}|${portals}|${ep}`;
}

function countResult(state: GameState): Result { const white = state.pieces.filter((piece) => piece.color === "white").length; const black = state.pieces.length - white; return white === black ? "draw" : white > black ? "white-win" : "black-win"; }
function finish(state: GameState, result: Result): GameState { state.phase = "terminal"; state.result = result; return state; }
export const defaultDeadPositionDetector: DeadPositionDetector = { isCertifiedDeadPosition: () => false };

export function resolveTerminal(state: GameState, detector: DeadPositionDetector = defaultDeadPositionDetector): GameState {
  const legal = legalMovesForSide({ ...state, repetitionHistory: {}, phase: "active", result: null });
  const inCheck = kingSquare(state, state.sideToMove) !== undefined && isAttacked(state, kingSquare(state, state.sideToMove)!, opposite(state.sideToMove));
  if (legal.length === 0 && inCheck) return finish(state, state.sideToMove === "white" ? "black-win" : "white-win");
  if (state.pieces.every((piece) => piece.type === "king")) return finish(state, "draw");
  if (legal.length === 0 || detector.isCertifiedDeadPosition(state) || (state.repetitionHistory[positionKey(state)] ?? 0) >= 3) return finish(state, countResult(state));
  return state;
}

export function displayAliases(square: LogicalSquare): string[] { return aliases(square); }
