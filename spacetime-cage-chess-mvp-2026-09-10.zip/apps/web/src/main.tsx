import { StrictMode, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { applyMove, initialState, legalMovesForSide, normalizeSquare, type GameState, type Move, type Piece } from "@cage/rules";
import "./styles.css";

const files = ["a", "b", "c", "d", "e", "f", "g", "h"];
const ranks = [8, 7, 6, 5, 4, 3, 2, 1];
const glyph: Record<Piece["type"], string> = { king: "K", queen: "Q", rook: "R", bishop: "B", pawn: "P" };

function physicalSquare(file: string, rank: number): string { return `${file}${rank}`; }
function occupancy(state: GameState, physical: string): Piece | undefined {
  const logical = normalizeSquare(physical); return logical === "X" ? undefined : state.pieces.find((piece) => piece.square === logical);
}
function isBuilding(state: GameState, physical: string): boolean {
  const logical = normalizeSquare(physical); if (logical === "X") return false;
  const portal = logical.startsWith("P") ? `H${logical[1]}` : logical.endsWith("Q") ? `V${logical[0]}` : undefined;
  return portal !== undefined && !state.portals[portal as keyof GameState["portals"]];
}

function App() {
  const [game, setGame] = useState<GameState>(() => initialState());
  const [selected, setSelected] = useState<string | null>(null);
  const moves = useMemo(() => selected === null ? [] : legalMovesForSide(game).filter((move) => move.from === selected), [game, selected]);
  const destinations = new Set(moves.map((move) => move.to));
  const handleSquare = (physical: string) => {
    const logical = normalizeSquare(physical);
    if (logical === "X") return;
    const targetMove = moves.find((move) => move.to === logical && (move.promotion === "queen" || move.promotion === undefined));
    if (targetMove) { const next = applyMove(game, targetMove); if (next) { setGame(next); setSelected(null); } return; }
    const occupant = occupancy(game, physical);
    setSelected(occupant?.color === game.sideToMove ? logical : null);
  };
  return <main>
    <header><div><p className="eyebrow">LOCAL TWO PLAYER MVP</p><h1>时空牢笼棋</h1></div><button onClick={() => { setGame(initialState()); setSelected(null); }}>重置对局</button></header>
    <section className="game-shell">
      <div className="board-wrap"><svg className="board" viewBox="0 0 800 800" role="img" aria-label="时空牢笼棋棋盘">
        {ranks.flatMap((rank, row) => files.map((file, column) => {
          const physical = physicalSquare(file, rank); const logical = normalizeSquare(physical); const occupant = occupancy(game, physical); const x = column * 100; const y = row * 100;
          const closed = isBuilding(game, physical); const canMove = logical !== "X" && destinations.has(logical);
          return <g key={physical} onClick={() => handleSquare(physical)} className="square">
            <rect x={x} y={y} width="100" height="100" className={`${(row + column) % 2 ? "dark" : "light"} ${logical === "X" ? "hole" : ""} ${selected === logical ? "selected" : ""} ${canMove ? "target" : ""}`} />
            {logical === "X" && <circle cx={x + 50} cy={y + 50} r="24" className="black-hole" />}
            {closed && <rect x={x + 31} y={y + 31} width="38" height="38" className="building" />}
            {occupant && <text x={x + 50} y={y + 64} className={`piece ${occupant.color}`}>{glyph[occupant.type]}</text>}
            {(file === "a" || rank === 1) && <text x={x + 7} y={y + 17} className="coordinate">{file === "a" ? rank : file}</text>}
          </g>;
        }))}
      </svg></div>
      <aside><div className="turn"><span className={`side-dot ${game.sideToMove}`}></span>{game.phase === "terminal" ? `对局结束：${game.result}` : `${game.sideToMove === "white" ? "白方" : "黑方"}行动`}</div>
        <p>逻辑格：48</p><p>开启门户：{Object.values(game.portals).filter(Boolean).length}/12</p><p>连续无吃子：{game.noPieceCapturePlyCount}/16 半回合</p><p>三次重复计数：{game.repetitionHistory[Object.keys(game.repetitionHistory).at(-1) ?? ""] ?? 0}</p>
        <p className="rule-note">双方各走 8 步未吃子时，立即按子数结算；捕获建筑物不重置计数。</p>
        <div className="legend"><span className="legend-building"></span>关闭门户建筑物 <span className="legend-hole"></span>黑洞 X</div>
      </aside>
    </section>
  </main>;
}
createRoot(document.getElementById("root")!).render(<StrictMode><App /></StrictMode>);
