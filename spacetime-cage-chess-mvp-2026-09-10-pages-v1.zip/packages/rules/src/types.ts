export const FILES = ["P", "b", "c", "d", "e", "f", "g"] as const;
export const RANKS = ["Q", "2", "3", "4", "5", "6", "7"] as const;

export type FileId = (typeof FILES)[number];
export type RankId = (typeof RANKS)[number];
export type LogicalSquare = "X" | "P2" | "P3" | "P4" | "P5" | "P6" | "P7" | `${Exclude<FileId, "P">}${RankId}`;
export type Color = "white" | "black";
export type PieceType = "pawn" | "rook" | "bishop" | "queen" | "king";
export type PortalId = "H2" | "H3" | "H4" | "H5" | "H6" | "H7" | "Vb" | "Vc" | "Vd" | "Ve" | "Vf" | "Vg";
export type Promotion = "queen" | "rook" | "bishop";
export type Phase = "active" | "terminal";
export type Result = "white-win" | "black-win" | "draw";

export interface Piece {
  id: string;
  color: Color;
  type: PieceType;
  square: Exclude<LogicalSquare, "X">;
  hasMoved: boolean;
}

export interface EnPassant {
  target: Exclude<LogicalSquare, "X">;
  pawnId: string;
  pawnSquare: Exclude<LogicalSquare, "X">;
  capturingSide: Color;
}

export interface GameState {
  sideToMove: Color;
  pieces: Piece[];
  portals: Record<PortalId, boolean>;
  enPassant: EnPassant | null;
  /** Consecutive half-moves without capturing an opposing piece. */
  noPieceCapturePlyCount: number;
  repetitionHistory: Record<string, number>;
  phase: Phase;
  result: Result | null;
}

export type MoveKind = "quiet" | "capture" | "portal-capture" | "en-passant";
export interface Move {
  pieceId: string;
  from: Exclude<LogicalSquare, "X">;
  to: Exclude<LogicalSquare, "X">;
  kind: MoveKind;
  capturedId?: string;
  portalId?: PortalId;
  promotion?: Promotion;
  isDoublePawnStep?: boolean;
}

export interface DeadPositionDetector {
  isCertifiedDeadPosition(state: Readonly<GameState>): boolean;
}
