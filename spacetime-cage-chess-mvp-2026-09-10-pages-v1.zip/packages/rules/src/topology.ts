import { FILES, RANKS, type FileId, type LogicalSquare, type PortalId, type RankId } from "./types.js";

const fileSet = new Set<string>(FILES);
const rankSet = new Set<string>(RANKS);
export const PORTAL_BY_SQUARE: Record<Exclude<LogicalSquare, "X">, PortalId | undefined> = {
  P2: "H2", P3: "H3", P4: "H4", P5: "H5", P6: "H6", P7: "H7",
  bQ: "Vb", cQ: "Vc", dQ: "Vd", eQ: "Ve", fQ: "Vf", gQ: "Vg",
  b2: undefined, c2: undefined, d2: undefined, e2: undefined, f2: undefined, g2: undefined,
  b3: undefined, c3: undefined, d3: undefined, e3: undefined, f3: undefined, g3: undefined,
  b4: undefined, c4: undefined, d4: undefined, e4: undefined, f4: undefined, g4: undefined,
  b5: undefined, c5: undefined, d5: undefined, e5: undefined, f5: undefined, g5: undefined,
  b6: undefined, c6: undefined, d6: undefined, e6: undefined, f6: undefined, g6: undefined,
  b7: undefined, c7: undefined, d7: undefined, e7: undefined, f7: undefined, g7: undefined
};

export const LOGICAL_SQUARES = Object.keys(PORTAL_BY_SQUARE) as Exclude<LogicalSquare, "X">[];
const modulo = (value: number) => ((value % 7) + 7) % 7;

export function normalizeSquare(coordinate: string): LogicalSquare {
  const value = coordinate.trim().toLowerCase();
  if (!/^[a-h][1-8]$/.test(value)) throw new Error(`Invalid physical coordinate: ${coordinate}`);
  const file = value[0]!;
  const rank = value[1]!;
  if ((file === "a" || file === "h") && (rank === "1" || rank === "8")) return "X";
  const normalizedFile = file === "a" || file === "h" ? "P" : file;
  const normalizedRank = rank === "1" || rank === "8" ? "Q" : rank;
  return `${normalizedFile}${normalizedRank}` as LogicalSquare;
}

export function squareParts(square: Exclude<LogicalSquare, "X">): { file: FileId; rank: RankId } {
  return { file: square[0] as FileId, rank: square.slice(1) as RankId };
}

export function nextLogicalSquare(square: Exclude<LogicalSquare, "X">, df: number, dr: number): LogicalSquare {
  const { file, rank } = squareParts(square);
  const nextFile = FILES[modulo(FILES.indexOf(file) + df)]!;
  const nextRank = RANKS[modulo(RANKS.indexOf(rank) + dr)]!;
  if (nextFile === "P" && nextRank === "Q") return "X";
  return `${nextFile}${nextRank}` as Exclude<LogicalSquare, "X">;
}

export function aliases(square: LogicalSquare): string[] {
  if (square === "X") return ["a1", "h1", "a8", "h8"];
  const { file, rank } = squareParts(square);
  const physicalFiles = file === "P" ? ["a", "h"] : [file];
  const physicalRanks = rank === "Q" ? ["1", "8"] : [rank];
  return physicalFiles.flatMap((f) => physicalRanks.map((r) => `${f}${r}`));
}

export function portalAt(square: Exclude<LogicalSquare, "X">): PortalId | undefined { return PORTAL_BY_SQUARE[square]; }
export function isPortal(square: Exclude<LogicalSquare, "X">): boolean { return portalAt(square) !== undefined; }
export function isClosedPortal(state: { portals: Record<PortalId, boolean> }, square: Exclude<LogicalSquare, "X">): boolean {
  const portal = portalAt(square); return portal !== undefined && !state.portals[portal];
}
export function isLogicalSquare(value: string): value is Exclude<LogicalSquare, "X"> { return value !== "X" && /^([Pbcdefg])(Q|[2-7])$/.test(value) && fileSet.has(value[0]!) && rankSet.has(value.slice(1)); }
