import type { Color, GameState, Piece, PortalId } from "./types.js";
import { positionKey } from "./engine.js";

export const PORTAL_IDS = ["H2", "H3", "H4", "H5", "H6", "H7", "Vb", "Vc", "Vd", "Ve", "Vf", "Vg"] as const satisfies readonly PortalId[];
export const opposite = (color: Color): Color => color === "white" ? "black" : "white";

export function initialState(): GameState {
  const pawnFiles = ["b", "c", "d", "e", "f", "g"] as const;
  const pieces: Piece[] = [
    ...pawnFiles.map((file): Piece => ({ id: `wp-${file}`, color: "white", type: "pawn", square: `${file}3` as Piece["square"], hasMoved: false })),
    { id: "wr-b", color: "white", type: "rook", square: "b2", hasMoved: false }, { id: "wr-g", color: "white", type: "rook", square: "g2", hasMoved: false },
    { id: "wb-c", color: "white", type: "bishop", square: "c2", hasMoved: false }, { id: "wb-f", color: "white", type: "bishop", square: "f2", hasMoved: false },
    { id: "wq", color: "white", type: "queen", square: "d2", hasMoved: false }, { id: "wk", color: "white", type: "king", square: "e2", hasMoved: false },
    ...pawnFiles.map((file): Piece => ({ id: `bp-${file}`, color: "black", type: "pawn", square: `${file}6` as Piece["square"], hasMoved: false })),
    { id: "br-b", color: "black", type: "rook", square: "b7", hasMoved: false }, { id: "br-g", color: "black", type: "rook", square: "g7", hasMoved: false },
    { id: "bb-c", color: "black", type: "bishop", square: "c7", hasMoved: false }, { id: "bb-f", color: "black", type: "bishop", square: "f7", hasMoved: false },
    { id: "bq", color: "black", type: "queen", square: "d7", hasMoved: false }, { id: "bk", color: "black", type: "king", square: "e7", hasMoved: false }
  ];
  const state: GameState = { sideToMove: "white", pieces, portals: Object.fromEntries(PORTAL_IDS.map((id) => [id, false])) as Record<PortalId, boolean>, enPassant: null, noPieceCapturePlyCount: 0, repetitionHistory: {}, phase: "active", result: null };
  state.repetitionHistory[positionKey(state)] = 1;
  return state;
}
