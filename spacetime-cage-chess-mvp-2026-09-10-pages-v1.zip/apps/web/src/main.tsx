import { StrictMode, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { applyMove, initialState, legalMovesForSide, normalizeSquare, type GameState, type Move, type Piece } from "@cage/rules";
import "./styles.css";

const files = ["a", "b", "c", "d", "e", "f", "g", "h"];
const ranks = [8, 7, 6, 5, 4, 3, 2, 1];
const glyph: Record<Piece["type"], Record<Piece["color"], string>> = {
  king: { white: "♔", black: "♚" },
  queen: { white: "♕", black: "♛" },
  rook: { white: "♖", black: "♜" },
  bishop: { white: "♗", black: "♝" },
  pawn: { white: "♙", black: "♟" },
};

function physicalSquare(file: string, rank: number): string { return `${file}${rank}`; }
function occupancy(state: GameState, physical: string): Piece | undefined {
  const logical = normalizeSquare(physical); return logical === "X" ? undefined : state.pieces.find((piece) => piece.square === logical);
}
function isBuilding(state: GameState, physical: string): boolean {
  const logical = normalizeSquare(physical); if (logical === "X") return false;
  const portal = logical.startsWith("P") ? `H${logical[1]}` : logical.endsWith("Q") ? `V${logical[0]}` : undefined;
  return portal !== undefined && !state.portals[portal as keyof GameState["portals"]];
}

function App() {
  const [game, setGame] = useState<GameState>(() => initialState());
  const [selected, setSelected] = useState<string | null>(null);
  const moves = useMemo(() => selected === null ? [] : legalMovesForSide(game).filter((move) => move.from === selected), [game, selected]);
  const destinations = new Set(moves.map((move) => move.to));
  const handleSquare = (physical: string) => {
    const logical = normalizeSquare(physical);
    if (logical === "X") return;
    const targetMove = moves.find((move) => move.to === logical && (move.promotion === "queen" || move.promotion === undefined));
    if (targetMove) { const next = applyMove(game, targetMove); if (next) { setGame(next); setSelected(null); } return; }
    const occupant = occupancy(game, physical);
    setSelected(occupant?.color === game.sideToMove ? logical : null);
  };
  const sideName = game.sideToMove === "white" ? "白方" : "黑方";
  const terminalLabel = game.result === "draw" ? "和棋" : game.result === "white-win" ? "白方胜" : "黑方胜";
  const openPortalCount = Object.values(game.portals).filter(Boolean).length;
  const repetitionCount = game.repetitionHistory[Object.keys(game.repetitionHistory).at(-1) ?? ""] ?? 0;

  return <main className="app-shell">
    <header className="app-header">
      <div className="brand"><span className="brand-mark" aria-hidden="true">♚</span><div><p className="eyebrow">LOCAL TWO PLAYER</p><h1>时空牢笼棋</h1></div></div>
      <button className="reset-button" onClick={() => { setGame(initialState()); setSelected(null); }} aria-label="重置对局"><span aria-hidden="true">↻</span> 重置</button>
    </header>
    <section className="game-shell">
      <div className="board-section">
        <div className="board-meta"><span>拓扑棋盘</span><span>48 个逻辑格</span></div>
        <div className="board-wrap"><svg className="board" viewBox="0 0 800 800" role="img" aria-label="时空牢笼棋棋盘">
        {ranks.flatMap((rank, row) => files.map((file, column) => {
          const physical = physicalSquare(file, rank); const logical = normalizeSquare(physical); const occupant = occupancy(game, physical); const x = column * 100; const y = row * 100;
          const closed = isBuilding(game, physical); const canMove = logical !== "X" && destinations.has(logical);
          return <g key={physical} onClick={() => handleSquare(physical)} className="square">
            <rect x={x} y={y} width="100" height="100" className={`${(row + column) % 2 ? "dark" : "light"} ${logical === "X" ? "hole" : ""} ${selected === logical ? "selected" : ""} ${canMove ? "target" : ""}`} />
            {logical === "X" && <circle cx={x + 50} cy={y + 50} r="24" className="black-hole" />}
            {closed && <g className="building"><rect x={x + 30} y={y + 35} width="40" height="35" rx="3" /><path d={`M ${x + 26} ${y + 36} L ${x + 50} ${y + 19} L ${x + 74} ${y + 36} Z`} /></g>}
            {occupant && <text x={x + 50} y={y + 67} className={`piece ${occupant.color}`}>{glyph[occupant.type][occupant.color]}</text>}
            {(file === "a" || rank === 1) && <text x={x + 7} y={y + 17} className="coordinate">{file === "a" ? rank : file}</text>}
          </g>;
        }))}
      </svg></div></div>
      <aside className="game-panel">
        <div className="turn-card"><span className={`side-piece ${game.sideToMove}`} aria-hidden="true">{game.sideToMove === "white" ? "♔" : "♚"}</span><div><span className="panel-kicker">{game.phase === "terminal" ? "对局结束" : "当前回合"}</span><div className="turn">{game.phase === "terminal" ? terminalLabel : `${sideName}行动`}</div></div></div>
        <div className="stat-grid"><div className="stat"><span>已开启门户</span><strong>{openPortalCount}<small>/12</small></strong></div><div className="stat"><span>重复局面</span><strong>{repetitionCount}<small> 次</small></strong></div></div>
        <div className="capture-meter"><div className="meter-heading"><span>无吃子计数</span><strong>{game.noPieceCapturePlyCount}<small>/16</small></strong></div><div className="meter-track"><span style={{ width: `${(game.noPieceCapturePlyCount / 16) * 100}%` }} /></div><p>双方各走 8 步未吃子时，立即按子数结算。</p></div>
        <div className="legend"><div><span className="legend-building" aria-hidden="true"></span><span>关闭门户建筑物</span></div><div><span className="legend-hole" aria-hidden="true"></span><span>黑洞 X</span></div></div>
      </aside>
    </section>
  </main>;
}
createRoot(document.getElementById("root")!).render(<StrictMode><App /></StrictMode>);
